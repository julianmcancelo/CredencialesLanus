<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion.php';

$mensaje = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['eliminar_persona'])) {
    $stmt = $pdo->prepare("DELETE FROM habilitaciones_personas WHERE id = ?");
    $stmt->execute([$_POST['eliminar_persona']]);
    $mensaje = "✅ Persona eliminada correctamente.";
  } elseif (isset($_POST['eliminar_vehiculo'])) {
    $stmt = $pdo->prepare("DELETE FROM habilitaciones_vehiculos WHERE id = ?");
    $stmt->execute([$_POST['eliminar_vehiculo']]);
    $mensaje = "✅ Vehículo eliminado correctamente.";
  } elseif (isset($_POST['eliminar_establecimiento'])) {
    $stmt = $pdo->prepare("DELETE FROM habilitaciones_establecimientos WHERE id = ?");
    $stmt->execute([$_POST['eliminar_establecimiento']]);
    $mensaje = "✅ Establecimiento eliminado correctamente.";
  } elseif (isset($_POST['habilitacion_id'], $_POST['establecimiento_id'])) {
    $stmt = $pdo->prepare("INSERT INTO habilitaciones_establecimientos (habilitacion_id, establecimiento_id) VALUES (?, ?)");
    $stmt->execute([$_POST['habilitacion_id'], $_POST['establecimiento_id']]);
    $mensaje = "✅ Establecimiento asociado correctamente.";
  }
}

$sql = "
SELECT 
  hg.id AS habilitacion_id, 
  hg.nro_licencia, 
  hg.estado, 
  hg.vigencia_inicio, 
  hg.vigencia_fin,

  COALESCE((
    SELECT JSON_ARRAYAGG(JSON_OBJECT('id', hp.id, 'nombre', p.nombre, 'rol', hp.rol))
    FROM habilitaciones_personas hp
    JOIN personas p ON p.id = hp.persona_id
    WHERE hp.habilitacion_id = hg.id
  ), JSON_ARRAY()) AS personas,

  COALESCE((
    SELECT JSON_ARRAYAGG(JSON_OBJECT('id', hv.id, 'dominio', v.dominio))
    FROM habilitaciones_vehiculos hv
    JOIN vehiculos v ON v.id = hv.vehiculo_id
    WHERE hv.habilitacion_id = hg.id
  ), JSON_ARRAY()) AS vehiculos,

  COALESCE((
    SELECT JSON_ARRAYAGG(JSON_OBJECT('id', he.id, 'nombre', e.nombre))
    FROM habilitaciones_establecimientos he
    JOIN establecimientos e ON e.id = he.establecimiento_id
    WHERE he.habilitacion_id = hg.id
  ), JSON_ARRAY()) AS establecimientos

FROM habilitaciones_generales hg
ORDER BY hg.id DESC
";

$stmt = $pdo->prepare($sql);
$stmt->execute();
$habilitaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);
$establecimientos = $pdo->query("SELECT id, nombre FROM establecimientos ORDER BY nombre")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Panel de Habilitaciones</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <style>
    .btn-opcion {
      @apply flex items-center gap-1 px-4 py-2 text-white text-sm font-semibold rounded shadow transition duration-150 ease-in-out;
    }
   

  .credencial {
    border: 1px solid #ddd;
    padding: 16px;
    background-color: white;
    border-radius: 8px;
    box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    font-size: 14px;
    line-height: 1.4;
  }

  @keyframes fade-in {
    from { opacity: 0; transform: scale(0.97); }
    to { opacity: 1; transform: scale(1); }
  }

  .animate-fade-in {
    animation: fade-in 0.2s ease-out;
  }
</style>



</head>
<body class="bg-gray-100 min-h-screen">
  <div class="bg-blue-500 text-white p-4 flex justify-between items-center">
    <h1 class="text-xl font-bold">#LaCiudadQueNosMerecemos</h1>
    <img src="https://www.lanus.gob.ar/img/logo-footer.svg" class="w-28" />
  </div>

  <div class="max-w-7xl mx-auto mt-6 px-4">
    <div class="bg-white rounded-xl shadow-lg p-6">
      <div class="flex justify-between items-center mb-6">
        <div>
          <h2 class="text-2xl font-bold text-[#891628] mb-1">Panel de Habilitaciones</h2>
          <p class="text-sm text-gray-600">Dirección Gral. de Movilidad y Transporte</p>
        </div>
        <div class="flex flex-wrap gap-2">
          <a href="registro_persona.php" class="btn-opcion bg-[#d32f2f] hover:bg-[#b71c1c]">➕ Persona</a>
          <a href="registro_vehiculo.php" class="btn-opcion bg-[#1976d2] hover:bg-[#0d47a1]">🚐 Vehículo</a>
          <a href="registro_habilitacion.php" class="btn-opcion bg-[#388e3c] hover:bg-[#1b5e20]">📄 Habilitación</a>
          <a href="asociar_establecimiento.php" class="btn-opcion bg-[#f57c00] hover:bg-[#e65100]">🏫 Establecimiento</a>
        </div>
      </div>


      <?php if ($mensaje): ?>
        <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4 text-center text-sm">
          <?= $mensaje ?>
        </div>
      <?php endif; ?>

      <div class="overflow-x-auto">
        <table class="w-full text-sm border border-gray-200 rounded">
          <thead class="bg-[#fcebea] text-[#891628] text-xs uppercase">
            <tr>
              <th class="px-4 py-2">#</th>
              <th class="px-4 py-2">Licencia</th>
              <th class="px-4 py-2">Estado</th>
              <th class="px-4 py-2">Vigencia</th>
              <th class="px-4 py-2">Personas</th>
              <th class="px-4 py-2">Vehículos</th>
              <th class="px-4 py-2">Establecimientos</th>
              <th class="px-4 py-2 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody class="bg-white divide-y divide-gray-200">
            <?php foreach ($habilitaciones as $item): ?>
              <?php
                $personas_raw = $item['personas'] ?? '[]';
$personas = is_string($personas_raw) ? json_decode($personas_raw, true) : [];
if (!is_array($personas)) $personas = [];

$roles = ['TITULAR' => false, 'CONDUCTOR' => false, 'CELADOR' => false];
foreach ($personas as $p) {
  if (isset($p['rol'])) {
    $roles[strtoupper($p['rol'])] = true;
  }
}
              ?>
              <tr>
                <td class="px-4 py-2 font-semibold text-gray-800">#<?= $item['habilitacion_id'] ?></td>
                <td class="px-4 py-2 text-[#891628] font-mono font-bold"><?= $item['nro_licencia'] ?></td>
                <td class="px-4 py-2">
                  <span class="px-2 py-1 text-xs rounded-full font-semibold <?= $item['estado'] === 'HABILITADO' ? 'bg-green-100 text-green-700' : ($item['estado'] === 'EN TRAMITE' ? 'bg-yellow-100 text-yellow-700' : 'bg-red-100 text-red-700') ?>">
                    <?= $item['estado'] ?>
                  </span>
                </td>
                <td class="px-4 py-2 text-sm text-gray-700">Del <?= $item['vigencia_inicio'] ?> al <?= $item['vigencia_fin'] ?></td>
                <td class="px-4 py-2 text-xs text-gray-800">
                  <div class="flex flex-wrap gap-1">
                    <?php foreach ($personas as $persona): ?>
                      <form method="POST" class="inline">
                        <span class="bg-gray-100 px-2 py-1 rounded-full flex items-center gap-1">
                          <?= $persona['nombre'] ?> (<?= $persona['rol'] ?>)
                          <button type="submit" name="eliminar_persona" value="<?= $persona['id'] ?>" class="text-red-600 hover:text-red-800">🗑️</button>
                        </span>
                      </form>
                    <?php endforeach; ?>
                    <?php foreach ($roles as $rol => $presente): ?>
                      <?php if (!$presente): ?>
                        <a href="cargar_persona.php?id=<?= $item['habilitacion_id'] ?>&rol=<?= strtolower($rol) ?>" class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">+ <?= ucfirst(strtolower($rol)) ?></a>
                      <?php endif; ?>
                    <?php endforeach; ?>
                  </div>
                </td>
                <td class="px-4 py-2 text-xs">
                  <div class="flex flex-wrap gap-1">
                    <?php
$vehiculos = json_decode($item['vehiculos'] ?? '[]', true);
if (!is_array($vehiculos)) $vehiculos = [];
?>

<?php foreach ($vehiculos as $vehiculo): ?>
  <form method="POST" class="inline">
    <span class="bg-blue-100 px-2 py-1 rounded-full flex items-center gap-1">
      <?= htmlspecialchars($vehiculo['dominio']) ?>
      <button type="submit" name="eliminar_vehiculo" value="<?= $vehiculo['id'] ?>" class="text-red-600 hover:text-red-800">🗑️</button>
    </span>
  </form>
<?php endforeach; ?>

<?php if (count($vehiculos) === 0): ?>
  <a href="cargar_vehiculo.php?id=<?= $item['habilitacion_id'] ?>" class="bg-blue-100 text-blue-700 px-2 py-1 rounded-full text-xs font-medium">+ Agregar vehículo</a>
<?php endif; ?>

                  </div>
                </td>
                <td class="px-4 py-2 text-xs">
                  <div class="flex flex-wrap gap-1">
                    <?php foreach (json_decode($item['establecimientos'] ?? '[]', true) as $est): ?>
                      <form method="POST" class="inline">
                        <span class="bg-red-100 px-2 py-1 rounded-full flex items-center gap-1">
                          <?= $est['nombre'] ?>
                          <button type="submit" name="eliminar_establecimiento" value="<?= $est['id'] ?>" class="text-red-600 hover:text-red-800">🗑️</button>
                        </span>
                      </form>
                    <?php endforeach; ?>
                  </div>
                </td>
                <td class="px-4 py-2 text-right space-y-1">



                  <a href="editar_habilitacion.php?id=<?= $item['habilitacion_id'] ?>" class="block text-yellow-600 hover:underline">Editar</a>
                  <a href="asociar_establecimiento.php?id=<?= $item['habilitacion_id'] ?>" class="block text-green-600 hover:underline">+ Establecimiento</a>
                  <a href="credencial.php?id=<?= $item['habilitacion_id'] ?>" class="block text-blue-600 hover:underline">Ver</a>
                </td>
              </tr>
            <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
<!-- MODAL DE CREDENCIAL -->
<div id="modalCredencial" class="hidden fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
  <div class="bg-white rounded-lg w-full max-w-4xl h-[90%] overflow-hidden shadow-lg">
    <div class="flex justify-between items-center bg-gray-100 px-4 py-2 border-b">
      <h2 class="text-lg font-bold text-gray-800">Credencial</h2>
      <button onclick="cerrarCredencial()" class="text-red-600 text-xl">&times;</button>
    </div>
    <iframe id="iframeCredencial" src="" class="w-full h-full border-0"></iframe>
  </div>
</div>










<script>
function verCredencial(id) {
  const modal = document.getElementById('modalCredencial');
  const contenido = document.getElementById('contenidoCredencial');
  modal.classList.remove('hidden');

  contenido.innerHTML = `<div class="text-gray-400 text-sm">Cargando credencial...</div>`;

  fetch('credencial.php?id=' + id)
    .then(res => res.text())
    .then(html => {
      contenido.innerHTML = html;
    })
    .catch(err => {
      contenido.innerHTML = '<p class="text-red-600">❌ Error al cargar la credencial.</p>';
    });
}

function cerrarCredencial() {
  document.getElementById('modalCredencial').classList.add('hidden');
  document.getElementById('contenidoCredencial').innerHTML = '';
}

function imprimirCredencial() {
  const contenido = document.getElementById('contenidoCredencial').innerHTML;
  const ventana = window.open('', '_blank');
  ventana.document.write(`
    <html><head><title>Imprimir Credencial</title>
    <style>
      body { margin: 0; font-family: sans-serif; }
      .credencial { display: flex; justify-content: center; align-items: center; height: 100vh; }
    </style>
    </head><body><div class="credencial">${contenido}</div></body></html>
  `);
  ventana.document.close();
  ventana.focus();
  ventana.print();
  ventana.close();
}
</script>



</script>





</body>
</html>
