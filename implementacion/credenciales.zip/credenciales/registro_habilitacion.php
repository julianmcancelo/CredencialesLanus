<?php
require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  if (isset($_POST['nro_licencia'], $_POST['resolucion'], $_POST['vigencia_inicio'], $_POST['vigencia_fin'], $_POST['estado'], $_POST['tipo'], $_POST['expte'])) {
    $stmt = $pdo->prepare("INSERT INTO habilitaciones_generales (anio, nro_licencia, resolucion, vigencia_inicio, vigencia_fin, estado, tipo, observaciones, expte) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
      date('Y'),  // Año actual
      $_POST['nro_licencia'],
      $_POST['resolucion'],
      $_POST['vigencia_inicio'],
      $_POST['vigencia_fin'],
      $_POST['estado'],
      $_POST['tipo'],
      $_POST['observaciones'],
      $_POST['expte']  // Agregar el campo expte
    ]);
    
    $mensaje = "✅ Habilitación registrada con éxito.";
  }
}
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <title>Registro de Habilitación</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-2xl bg-white p-6 rounded-lg shadow-lg">
    <h1 class="text-2xl font-bold text-[#891628] mb-4 text-center">Registrar Nueva Habilitación</h1>
    <?php if (isset($mensaje)): ?>
      <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4 text-sm"> <?= $mensaje ?> </div>
    <?php endif; ?>
    <form method="POST" class="grid grid-cols-1 md:grid-cols-2 gap-4">
      <input name="anio" type="number" placeholder="Año (Ej: 2025)" class="border px-3 py-2 rounded" required>
      <input name="nro_licencia" placeholder="N° de Licencia (Ej: 068-0123/25)" class="border px-3 py-2 rounded" required>
      <input name="resolucion" placeholder="Resolución" class="border px-3 py-2 rounded">
      <select name="tipo" class="border px-3 py-2 rounded" required>
        <option value="HABILITACION">Habilitación</option>
        <option value="RENOVACION">Renovación</option>
        <option value="CAMBIO MATERIAL">Cambio de Material</option>
        <option value="CAMBIO TITULAR">Cambio de Titular</option>
      </select>
      <input name="vigencia_inicio" type="date" class="border px-3 py-2 rounded" required>
      <input name="vigencia_fin" type="date" class="border px-3 py-2 rounded" required>
      <select name="estado" class="border px-3 py-2 rounded" required>
        <option value="HABILITADO">HABILITADO</option>
        <option value="NO HABILITADO">NO HABILITADO</option>
        <option value="EN TRAMITE">EN TRÁMITE</option>
        <option value="INICIADO">INICIADO</option>
      </select>
        <input type="text" name="expte" placeholder="Expte" required> <!-- Aquí agregamos el campo expte -->

      <div class="md:col-span-2">
        <button type="submit" class="w-full bg-[#891628] text-white py-2 rounded hover:bg-red-800">Registrar Habilitación</button>
      </div>
    </form>
    <div class="text-center mt-4">
      <a href="index.php" class="text-sm text-blue-700 hover:underline">← Volver al Panel</a>
    </div>
  </div>
</body>
</html>
