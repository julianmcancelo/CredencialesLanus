<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion.php';

$id = isset($_GET['id']) ? intval($_GET['id']) : 1;

$sql = "
SELECT hg.*, 
       p.nombre AS titular_nombre, p.dni AS titular_dni, p.cuit, p.foto_url AS titular_foto,
       c.nombre AS conductor_nombre, c.dni AS conductor_dni, c.foto_url AS conductor_foto,
       hc.licencia_categoria,
       ce.nombre AS celador_nombre, ce.dni AS celador_dni,
       e.nombre AS escuela_nombre, e.domicilio AS escuela_domicilio, e.localidad, e.latitud, e.longitud, e.direccion,
       v.marca, v.modelo, v.motor, v.asientos
FROM habilitaciones_generales hg
LEFT JOIN habilitaciones_personas ht ON ht.habilitacion_id = hg.id AND ht.rol = 'TITULAR'
LEFT JOIN personas p ON p.id = ht.persona_id
LEFT JOIN habilitaciones_personas hc ON hc.habilitacion_id = hg.id AND hc.rol = 'CONDUCTOR'
LEFT JOIN personas c ON c.id = hc.persona_id
LEFT JOIN habilitaciones_personas hce ON hce.habilitacion_id = hg.id AND hce.rol = 'CELADOR'
LEFT JOIN personas ce ON ce.id = hce.persona_id
LEFT JOIN habilitaciones_establecimientos he ON he.habilitacion_id = hg.id
LEFT JOIN establecimientos e ON e.id = he.establecimiento_id
LEFT JOIN habilitaciones_vehiculos hv ON hv.habilitacion_id = hg.id
LEFT JOIN vehiculos v ON v.id = hv.vehiculo_id
WHERE hg.id = :id
";

$stmt = $pdo->prepare($sql);
$stmt->execute(['id' => $id]);
$data = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$data) {
    die("No se encontró la habilitación.");
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Credencial Transporte</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet" />
  <link href="styles.css" rel="stylesheet" />
</head>
<body class="flex items-center justify-center min-h-screen bg-gray-100">
  <div class="credencial w-full max-w-2xl bg-white rounded-xl shadow-lg p-4">
    <div class="header-lanus flex justify-between items-center bg-blue-500 text-white p-4 rounded-t-xl">
      <h1 class="text-xl font-bold">#LaCiudadQueNosMerecemos</h1>
      <img src="https://www.lanus.gob.ar/img/logo-footer.svg" class="w-32" />
    </div>

    <div class="institucional p-4">
      <div class="flex justify-between text-sm font-bold text-gray-800">
        <div>
          <p>Lanús</p>
          <p>Gobierno</p>
        </div>
        <div class="text-right">
          <p>Dirección Gral. de Movilidad y Transporte</p>
          <p>Subsecretaría de Ordenamiento Urbano</p>
        </div>
      </div>
    </div>

    <div class="datos-estado p-4 grid grid-cols-2 gap-2 text-sm uppercase">
      <div>N° de Licencia: <span><?= $data['nro_licencia'] ?></span></div>
      <div>Resolución: <span><?= $data['resolucion'] ?></span></div>
      <div>Vigencia: <span><?= $data['vigencia_inicio'] ?> - <?= $data['vigencia_fin'] ?></span></div>
      <div>Estado: <span style="color:green"><?= $data['estado'] ?></span></div>
    </div>

    <div class="info-vehiculo p-4 grid grid-cols-2 gap-4 text-sm">
      <div>
        <p>Titular: <?= $data['titular_nombre'] ?></p>
        <p>DNI: <?= $data['titular_dni'] ?> - CUIT: <?= $data['cuit'] ?></p>
        <p>Marca: <?= $data['marca'] ?> - Modelo: <?= $data['modelo'] ?></p>
        <p>Motor: <?= $data['motor'] ?></p>
        <p>Asientos: <?= $data['asientos'] ?></p>
      </div>
      <div class="flex justify-center">
        <img src="<?= $data['titular_foto'] ?>" class="rounded-full border-2 border-red-700 w-24 h-24 object-cover" />
      </div>
    </div>

    <div class="seccion px-4 pb-4">
      <h3 class="font-bold text-red-700">Establecimiento Educativo</h3>
      <p><strong>Nombre:</strong> <?= $data['escuela_nombre'] ?></p>
      <p><strong>Domicilio:</strong> <?= $data['escuela_domicilio'] ?> - <?= $data['localidad'] ?></p>
      <?php if (!empty($data['direccion'])): ?>
        <p><strong>Dirección exacta:</strong> <?= $data['direccion'] ?></p>
      <?php endif; ?>

    </div>

    <div class="seccion px-4 pb-4">
      <h3 class="font-bold text-red-700">Conductor Autorizado</h3>
      <div class="flex justify-between items-center">
        <div>
          <p><?= $data['conductor_nombre'] ?> - DNI: <?= $data['conductor_dni'] ?></p>
          <p class="text-xs uppercase text-gray-600">Licencia: <?= $data['licencia_categoria'] ?></p>
        </div>
        <img src="<?= $data['conductor_foto'] ?>" class="rounded-full border-2 border-red-700 w-20 h-20 object-cover" />
      </div>
    </div>

    <div class="seccion px-4 pb-4">
      <h3 class="font-bold text-red-700">Celador Autorizado</h3>
      <p><?= $data['celador_nombre'] ?> - DNI: <?= $data['celador_dni'] ?></p>
    </div>

    <div class="flex justify-center py-4">
      <canvas id="qrcode" width="100" height="100"></canvas>
    </div>

    <div class="legal text-xs text-center text-gray-600 px-4 pb-2">
      <p>El presente certificado solo es válido junto a la VTV y seguro al día.</p>
      <p>Válido para el Ciclo Lectivo <?= $data['anio'] ?>. ART. 9 RES 122/18 (...)</p>
    </div>

    <div class="text-center mt-2 no-print">
      <button onclick="window.print()" class="btn-imprimir px-4 py-2 bg-red-700 text-white rounded">🖨️ Imprimir</button>
    </div>
  </div>

  <script src="https://cdn.jsdelivr.net/npm/qrious@4.0.2/dist/qrious.min.js"></script>
  <script>
    new QRious({
      element: document.getElementById('qrcode'),
      value: 'https://transportelanus.com.ar/credenciales/credencial.php?id=<?= $data["id"] ?>',
      size: 100,
      level: 'H'
    });
  </script>
</body>
</html>
