<?php
require_once 'conexion.php';

$habilitacion_id = $_GET['id'] ?? null;
if (!$habilitacion_id || !is_numeric($habilitacion_id)) {
  die("ID de habilitación no válida.");
}

$link_credencial = "./credencial.php?id=$habilitacion_id";
$qr_path = "qrs/qr_$habilitacion_id.png";

// Obtener teléfono del titular
$stmt = $pdo->prepare("SELECT p.telefono FROM habilitaciones_personas hp JOIN personas p ON p.id = hp.persona_id WHERE hp.habilitacion_id = ? AND hp.rol = 'TITULAR' AND p.telefono IS NOT NULL LIMIT 1");
$stmt->execute([$habilitacion_id]);
$telefono_titular = $stmt->fetchColumn();

?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Enviar Credencial</title>
  <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center">
  <div class="bg-white rounded-xl shadow-lg max-w-md w-full p-6 space-y-6">
    <h2 class="text-2xl font-bold text-center text-[#891628]">Enviar Credencial</h2>

    <div class="text-center">
      <img src="<?= $qr_path ?>" alt="QR Habilitación" class="mx-auto w-32 h-32 border rounded mb-2" onerror="this.style.display='none'" />
      <a href="<?= $link_credencial ?>" target="_blank" class="text-blue-600 underline text-sm">Ver Credencial Completa</a>
    </div>

    <div>
      <label class="block font-medium text-sm mb-1">📱 Enviar por WhatsApp:</label>
      <input type="text" id="telefono" placeholder="Ej: 5491123456789" class="w-full border rounded px-3 py-2 text-sm" value="<?= htmlspecialchars($telefono_titular ?? '') ?>" />
      <button onclick="enviarWhatsApp()" class="mt-2 w-full bg-green-600 hover:bg-green-700 text-white py-2 rounded text-sm">Enviar por WhatsApp</button>
    </div>

    <div>
      <label class="block font-medium text-sm mb-1">📧 Enviar por Email:</label>
      <input type="email" id="email" placeholder="usuario@ejemplo.com" class="w-full border rounded px-3 py-2 text-sm" />
      <button onclick="enviarEmail()" class="mt-2 w-full bg-blue-600 hover:bg-blue-700 text-white py-2 rounded text-sm">Enviar por Correo</button>
    </div>
  </div>

  <script>
    function enviarWhatsApp() {
      const telefono = document.getElementById("telefono").value.trim();
      const link = "<?= $link_credencial ?>";
      if (!telefono) return alert("📱 Ingresá un número válido");
      const mensaje = `Hola, te enviamos tu credencial digital para transporte escolar. Podés verla acá:\n\n${link}`;
      window.open(`https://wa.me/${telefono}?text=${encodeURIComponent(mensaje)}`, "_blank");
    }

    function enviarEmail() {
      const email = document.getElementById("email").value.trim();
      if (!email) return alert("📧 Ingresá un correo electrónico válido");
      fetch("enviar_correo.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: `email=${encodeURIComponent(email)}&id=<?= $habilitacion_id ?>`
      })
      .then(res => res.text())
      .then(msg => alert(msg))
      .catch(() => alert("❌ Error al enviar el correo"));
    }
  </script>
</body>
</html>