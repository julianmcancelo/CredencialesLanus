<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once 'conexion.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $habilitacion_id = $_POST['habilitacion_id'];
  $establecimiento_id = $_POST['establecimiento_id'];

  $stmt = $pdo->prepare("INSERT INTO habilitaciones_establecimientos (habilitacion_id, establecimiento_id) VALUES (?, ?)");
  if ($stmt->execute([$habilitacion_id, $establecimiento_id])) {
    $mensaje = "✅ Establecimiento asociado correctamente.";
  } else {
    $mensaje = "❌ Error al asociar establecimiento.";
  }
}

$stmt = $pdo->query("SELECT id, nombre, domicilio, localidad FROM establecimientos ORDER BY nombre ASC");
$establecimientos = $stmt->fetchAll(PDO::FETCH_ASSOC);
$habilitacion_id = isset($_GET['id']) ? intval($_GET['id']) : 0;
?>
<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Asociar Establecimiento</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 min-h-screen flex items-center justify-center p-6">
  <div class="w-full max-w-xl bg-white p-6 rounded-xl shadow-lg">
    <h1 class="text-2xl font-bold text-blue-700 text-center mb-4">Asociar Establecimiento</h1>

    <?php if (isset($mensaje)): ?>
      <div class="bg-green-100 text-green-800 px-4 py-2 rounded mb-4 text-sm text-center">
        <?= $mensaje ?>
      </div>
    <?php endif; ?>

    <form method="POST" class="space-y-4">
      <input type="hidden" name="habilitacion_id" value="<?= $habilitacion_id ?>">

      <label class="block text-sm font-semibold text-gray-700">Seleccionar Establecimiento</label>
      <select name="establecimiento_id" required class="w-full border border-gray-300 px-3 py-2 rounded shadow-sm">
        <option value="" disabled selected>-- Selecciona un establecimiento --</option>
        <?php foreach ($establecimientos as $e): ?>
          <option value="<?= $e['id'] ?>">
            <?= htmlspecialchars($e['nombre'] . " - " . $e['domicilio'] . ", " . $e['localidad']) ?>
          </option>
        <?php endforeach; ?>
      </select>

      <div class="text-center">
        <button type="submit" class="bg-blue-600 text-white px-6 py-2 rounded hover:bg-blue-700">Asociar</button>
      </div>
    </form>

    <div class="text-center mt-4">
      <a href="index.php" class="text-sm text-blue-600 hover:underline">&larr; Volver al Panel</a>
    </div>
  </div>
</body>
</html>
