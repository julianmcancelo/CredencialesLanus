<?php
require_once 'conexion.php';

$stmt = $pdo->query("SELECT * FROM personas ORDER BY id DESC");
$personas = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang=\"es\">
<head>
  <meta charset=\"UTF-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <title>Listado de Personas</title>
  <script src=\"https://cdn.tailwindcss.com\"></script>
</head>
<body class=\"bg-gray-100 min-h-screen p-6\">
  <div class=\"max-w-6xl mx-auto\">
    <h1 class=\"text-2xl font-bold mb-4 text-center text-blue-700\">Listado de Personas Registradas</h1>
    <div class=\"bg-white shadow-md rounded-lg overflow-x-auto\">
      <table class=\"min-w-full table-auto text-sm\">
        <thead class=\"bg-gray-200 text-gray-700 uppercase\">
          <tr>
            <th class=\"px-4 py-2\">ID</th>
            <th class=\"px-4 py-2\">Nombre</th>
            <th class=\"px-4 py-2\">DNI</th>
            <th class=\"px-4 py-2\">CUIT</th>
            <th class=\"px-4 py-2\">Teléfono</th>
            <th class=\"px-4 py-2\">Email</th>
            <th class=\"px-4 py-2\">Foto</th>
            <th class=\"px-4 py-2\">Editar</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($personas as $p): ?>
          <tr class=\"border-b hover:bg-gray-50\">
            <td class=\"px-4 py-2\"><?php echo $p['id']; ?></td>
            <td class=\"px-4 py-2\"><?php echo htmlspecialchars($p['nombre']); ?></td>
            <td class=\"px-4 py-2\"><?php echo $p['dni']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $p['cuit']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $p['telefono']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $p['email']; ?></td>
            <td class=\"px-4 py-2\">
              <?php if ($p['foto_url']): ?>
                <img src=\"<?php echo $p['foto_url']; ?>\" alt=\"Foto\" class=\"w-10 h-10 rounded-full object-cover border\">
              <?php else: ?>
                <span class=\"text-gray-400\">-</span>
              <?php endif; ?>
            </td>
            <td class=\"px-4 py-2\">
              <a href=\"editar_persona.php?id=<?php echo $p['id']; ?>\" class=\"text-yellow-600 hover:underline\">Editar</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class=\"text-center mt-4\">
      <a href=\"index.php\" class=\"text-sm text-blue-700 hover:underline\">← Volver al Panel</a>
    </div>
  </div>
</body>
</html>
