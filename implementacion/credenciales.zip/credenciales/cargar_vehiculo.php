<?php
require_once 'conexion.php';

$mensaje = null;

// Obtener los vehículos registrados
$stmt = $pdo->prepare("SELECT id, dominio, marca, modelo FROM vehiculos");
$stmt->execute();
$vehiculos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obtener las habilitaciones disponibles
$stmt = $pdo->prepare("SELECT id, nro_licencia FROM habilitaciones_generales ORDER BY id DESC");
$stmt->execute();
$habilitaciones = $stmt->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['vehiculo_id'], $_POST['habilitacion_id'])) {
        // Recuperar los datos enviados
        $vehiculo_id = $_POST['vehiculo_id'];
        $habilitacion_id = $_POST['habilitacion_id'];

        // Asociar el vehículo con la habilitación
        $stmt = $pdo->prepare("INSERT INTO habilitaciones_vehiculos (habilitacion_id, vehiculo_id) VALUES (?, ?)");
        $stmt->execute([$habilitacion_id, $vehiculo_id]);

        // Mensaje de éxito
        $mensaje = "✅ Vehículo asociado correctamente a la habilitación.";
    } else {
        // Error si faltan datos
        $mensaje = "❌ Error: Seleccione un vehículo y una habilitación.";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Asociar Vehículo a Habilitación</title>
  <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-50 min-h-screen">

  <header class="bg-[#00adee] text-white p-4 shadow">
    <div class="max-w-7xl mx-auto flex justify-between items-center">
      <h1 class="text-2xl font-bold tracking-wide">#LaCiudadQueNosMerecemos</h1>
      <a href="dashboard.php" class="text-white hover:text-gray-300">Volver al Dashboard</a>
    </div>
  </header>

  <div class="max-w-7xl mx-auto p-4">
    <h2 class="text-2xl font-semibold mb-6">Asociar Vehículo a Habilitación</h2>

    <?php if ($mensaje): ?>
      <div class="bg-green-100 border border-green-300 text-green-800 px-4 py-3 rounded mb-4 shadow">
        <?= $mensaje ?>
      </div>
    <?php endif; ?>

    <!-- Formulario para asociar vehículo con habilitación -->
    <form method="POST" class="bg-white p-6 rounded shadow">
      <div class="space-y-4">
        <div>
          <label for="habilitacion_id" class="block text-gray-700">Selecciona una Habilitación</label>
          <select name="habilitacion_id" id="habilitacion_id" class="w-full border px-3 py-2 rounded" required>
            <option value="" disabled selected>Selecciona una habilitación</option>
            <?php foreach ($habilitaciones as $habilitacion): ?>
              <option value="<?= $habilitacion['id'] ?>"><?= $habilitacion['nro_licencia'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div>
          <label for="vehiculo_id" class="block text-gray-700">Selecciona un Vehículo</label>
          <select name="vehiculo_id" id="vehiculo_id" class="w-full border px-3 py-2 rounded" required>
            <option value="" disabled selected>Selecciona un vehículo</option>
            <?php foreach ($vehiculos as $vehiculo): ?>
              <option value="<?= $vehiculo['id'] ?>"><?= $vehiculo['dominio'] ?> - <?= $vehiculo['marca'] ?> <?= $vehiculo['modelo'] ?></option>
            <?php endforeach; ?>
          </select>
        </div>

        <div class="flex justify-end gap-4">
          <button type="reset" class="px-4 py-2 bg-gray-200 text-gray-800 rounded">Cancelar</button>
          <button type="submit" class="px-4 py-2 bg-blue-600 text-white rounded">Guardar</button>
        </div>
      </div>
    </form>
  </div>

</body>
</html>
