<?php
require_once 'conexion.php';

$stmt = $pdo->query("SELECT * FROM vehiculos ORDER BY id DESC");
$vehiculos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang=\"es\">
<head>
  <meta charset=\"UTF-8\">
  <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\">
  <title>Listado de Vehículos</title>
  <script src=\"https://cdn.tailwindcss.com\"></script>
</head>
<body class=\"bg-gray-100 min-h-screen p-6\">
  <div class=\"max-w-6xl mx-auto\">
    <h1 class=\"text-2xl font-bold mb-4 text-center text-blue-700\">Listado de Vehículos Registrados</h1>
    <div class=\"bg-white shadow-md rounded-lg overflow-x-auto\">
      <table class=\"min-w-full table-auto text-sm\">
        <thead class=\"bg-gray-200 text-gray-700 uppercase\">
          <tr>
            <th class=\"px-4 py-2\">ID</th>
            <th class=\"px-4 py-2\">Dominio</th>
            <th class=\"px-4 py-2\">Marca</th>
            <th class=\"px-4 py-2\">Modelo</th>
            <th class=\"px-4 py-2\">Motor</th>
            <th class=\"px-4 py-2\">Asientos</th>
            <th class=\"px-4 py-2\">Año</th>
            <th class=\"px-4 py-2\">Tipo</th>
            <th class=\"px-4 py-2\">Editar</th>
          </tr>
        </thead>
        <tbody>
          <?php foreach ($vehiculos as $v): ?>
          <tr class=\"border-b hover:bg-gray-50\">
            <td class=\"px-4 py-2\"><?php echo $v['id']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['dominio']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['marca']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['modelo']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['motor']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['asientos']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['a\u00f1o']; ?></td>
            <td class=\"px-4 py-2\"><?php echo $v['tipo']; ?></td>
            <td class=\"px-4 py-2\">
              <a href=\"editar_vehiculo.php?id=<?php echo $v['id']; ?>\" class=\"text-yellow-600 hover:underline\">Editar</a>
            </td>
          </tr>
          <?php endforeach; ?>
        </tbody>
      </table>
    </div>
    <div class=\"text-center mt-4\">
      <a href=\"index.php\" class=\"text-sm text-blue-700 hover:underline\">← Volver al Panel</a>
    </div>
  </div>
</body>
</html>
